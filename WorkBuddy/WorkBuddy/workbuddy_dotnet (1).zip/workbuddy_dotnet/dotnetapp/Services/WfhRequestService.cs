using dotnetapp.Data;
using dotnetapp.Models;
using dotnetapp.Exceptions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace dotnetapp.Services
{
    public class WfhRequestService
    {
        private readonly ApplicationDbContext _context;

        public WfhRequestService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<WfhRequest>> GetAllWfhRequests()
        {
            return await _context.WfhRequests.Include(r => r.User).ToListAsync();
        }

        public async Task<WfhRequest> GetWfhRequestById(int wfhRequestId)
        {
            return await _context.WfhRequests.FirstOrDefaultAsync(wr => wr.WfhRequestId == wfhRequestId);
        }

public async Task<bool> AddWfhRequest(WfhRequest wfhRequest)
{
    var overlappingWfhRequest = await _context.WfhRequests
        .Where(wr => wr.UserId == wfhRequest.UserId)
        .Where(wr => wr.StartDate <= wfhRequest.EndDate && wr.EndDate >= wfhRequest.StartDate)
        .FirstOrDefaultAsync();

    if (overlappingWfhRequest != null)
    {
        throw new WfhException("There is already a WFH request for these dates");
    }

    _context.WfhRequests.Add(wfhRequest);
    await _context.SaveChangesAsync();
    return true;
}

public async Task<bool> UpdateWfhRequest(int wfhRequestId, WfhRequest wfhRequest)
{
    var existingWfhRequest = await _context.WfhRequests.FirstOrDefaultAsync(wr => wr.WfhRequestId == wfhRequestId);

    if (existingWfhRequest == null)
        return false;

    // Check for overlapping WFH requests (excluding the current WFH request being updated)
    var overlappingWfhRequest = await _context.WfhRequests
        .Where(wr => wr.UserId == wfhRequest.UserId && wr.WfhRequestId != wfhRequestId)
        .Where(wr => wr.StartDate <= wfhRequest.EndDate && wr.EndDate >= wfhRequest.StartDate)
        .FirstOrDefaultAsync();

    if (overlappingWfhRequest != null)
    {
        throw new WfhException("There is already a WFH request for these dates");
    }

    wfhRequest.WfhRequestId = wfhRequestId;
    _context.Entry(existingWfhRequest).CurrentValues.SetValues(wfhRequest);
    await _context.SaveChangesAsync();
    return true;
}

        public async Task<bool> DeleteWfhRequest(int wfhRequestId)
        {
            var wfhRequest = await _context.WfhRequests.FirstOrDefaultAsync(wr => wr.WfhRequestId == wfhRequestId);
            if (wfhRequest == null)
                return false;

            _context.WfhRequests.Remove(wfhRequest);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<IEnumerable<WfhRequest>> GetWfhRequestsByUserId(int userId)
        {
            return await _context.WfhRequests.Where(wr => wr.UserId == userId).ToListAsync();
        }
    }

}
