﻿namespace dotnetapp.Models
{
    public static class UserRoles
    {
        public const string Admin = "Employee";

        public const string User = "Manager";
    }
}
