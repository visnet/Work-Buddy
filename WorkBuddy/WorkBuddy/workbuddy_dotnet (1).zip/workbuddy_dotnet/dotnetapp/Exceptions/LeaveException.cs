using System;

namespace dotnetapp.Exceptions
{
public class LeaveException : Exception
{
    public LeaveException(string message) : base(message)
    {
    }
}

}