using System;

namespace dotnetapp.Exceptions
{
public class WfhException : Exception
{
    public WfhException(string message) : base(message)
    {
    }
}

}