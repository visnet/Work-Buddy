using dotnetapp.Models;
using dotnetapp.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace dotnetapp.Controllers
{
    [Route("api/wfhrequest")]
    [ApiController]
    public class WfhRequestController : ControllerBase
    {
        private readonly WfhRequestService _wfhRequestService;

        public WfhRequestController(WfhRequestService wfhRequestService)
        {
            _wfhRequestService = wfhRequestService;
        }

        // [Authorize]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<WfhRequest>>> GetAllWfhRequests()
        {
            var wfhRequests = await _wfhRequestService.GetAllWfhRequests();
            return Ok(wfhRequests);
        }

        // [Authorize(Roles = "Admin,User")]
        [HttpGet("{wfhRequestId}")]
        public async Task<ActionResult<WfhRequest>> GetWfhRequestById(int wfhRequestId)
        {
            var wfhRequest = await _wfhRequestService.GetWfhRequestById(wfhRequestId);

            if (wfhRequest == null)
                return NotFound(new { message = "Cannot find any WFH request" });

            return Ok(wfhRequest);
        }

        // [Authorize(Roles = "User")]
        [HttpPost]
        public async Task<ActionResult> AddWfhRequest([FromBody] WfhRequest wfhRequest)
        {
            try
            {
                var success = await _wfhRequestService.AddWfhRequest(wfhRequest);
                if (success)
                    return Ok(new { message = "WFH request added successfully" });
                else
                    return StatusCode(500, new { message = "Failed to add WFH request" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }

        // [Authorize(Roles = "Admin")]
        [HttpPut("{wfhRequestId}")]
        public async Task<ActionResult> UpdateWfhRequest(int wfhRequestId, [FromBody] WfhRequest wfhRequest)
        {
            try
            {
                var success = await _wfhRequestService.UpdateWfhRequest(wfhRequestId, wfhRequest);

                if (success)
                    return Ok(new { message = "WFH request updated successfully" });
                else
                    return NotFound(new { message = "Cannot find any WFH request" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }

        // [Authorize(Roles = "Admin")]
        [HttpDelete("{wfhRequestId}")]
        public async Task<ActionResult> DeleteWfhRequest(int wfhRequestId)
        {
            try
            {
                var success = await _wfhRequestService.DeleteWfhRequest(wfhRequestId);

                if (success)
                    return Ok(new { message = "WFH request deleted successfully" });
                else
                    return NotFound(new { message = "Cannot find any WFH request" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = ex.Message });
            }
        }
        [HttpGet("user/{userId}")]
        public async Task<ActionResult<IEnumerable<WfhRequest>>> GetWfhRequestsByUserId(int userId)
        {
            var wfhRequests = await _wfhRequestService.GetWfhRequestsByUserId(userId);
            return Ok(wfhRequests);
        }
    }
}
