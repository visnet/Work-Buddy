import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ErrorComponent } from './components/error/error.component';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { HomeComponent } from './components/home/home.component';
import { AuthGuard } from './components/authguard/auth.guard';

import { AdminviewfeedbackComponent } from './components/adminviewfeedback/adminviewfeedback.component';
import { UserviewfeedbackComponent } from './components/userviewfeedback/userviewfeedback.component';
import { UseraddfeedbackComponent } from './components/useraddfeedback/useraddfeedback.component';
import { AddwfhComponent } from './components/addwfh/addwfh.component';
import { MywfhComponent } from './components/mywfh/mywfh.component';
import { MyleaveComponent } from './components/myleave/myleave.component';
import { AddleaveComponent } from './components/addleave/addleave.component';
import { ViewwfhComponent } from './components/viewwfh/viewwfh.component';
import { ViewleaveComponent } from './components/viewleave/viewleave.component';
import { ViewemployeesComponent } from './components/viewemployees/viewemployees.component';

const routes: Routes = [
  {path: '', component: HomeComponent},
  {path: 'login', component: LoginComponent },
  {path: 'signup', component: RegistrationComponent },
  {path: 'error', component: ErrorComponent },
  {path :'admin/view/feedback', component: AdminviewfeedbackComponent},
  {path :'user/view/feedback', component: UserviewfeedbackComponent},
  {path :'user/add/feedback', component: UseraddfeedbackComponent},

// --------------------------------------------------

{path: 'employee/addwfh', component: AddwfhComponent, canActivate: [AuthGuard]},
{path: 'employee/view/wfh', component: MywfhComponent, canActivate: [AuthGuard]},
{path: 'employee/editwfh/:id', component: AddwfhComponent, canActivate: [AuthGuard]},
{path: 'employee/view/leave', component: MyleaveComponent, canActivate: [AuthGuard]},
{path: 'employee/addleave', component: AddleaveComponent, canActivate: [AuthGuard]},
{path: 'employee/editleave/:id', component: AddleaveComponent, canActivate: [AuthGuard]},


{path: 'manager/view/wfh', component: ViewwfhComponent, canActivate: [AuthGuard]},
{path: 'manager/view/leave', component: ViewleaveComponent, canActivate: [AuthGuard]},
{path: 'manager/view/employee', component: ViewemployeesComponent},



  { path: '**', redirectTo: '/error' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
