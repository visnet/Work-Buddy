import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { apiUrl } from 'src/apiconfig';
import { LeaveRequest } from '../models/leaveRequest.model';

@Injectable({
  providedIn: 'root'
})
export class LeaveService {
  public apiUrl = apiUrl; // Update with your API URL

  constructor(private http: HttpClient) { }

  getAllLeaveRequests(): Observable<LeaveRequest[]> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.get<LeaveRequest[]>(`${this.apiUrl}/api/leaverequest`, { headers });
  }

  getLeaveRequestById(leaveRequestId: number): Observable<LeaveRequest> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.get<LeaveRequest>(`${this.apiUrl}/api/leaverequest/${leaveRequestId}`, { headers });
  }

  addLeaveRequest(requestObject: LeaveRequest): Observable<LeaveRequest> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.post<LeaveRequest>(`${this.apiUrl}/api/leaverequest`, requestObject, { headers });
  }
  getLeaveRequestsByUserId(userId: number): Observable<LeaveRequest[]> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.get<LeaveRequest[]>(`${this.apiUrl}/api/leaverequest/user/${userId}`, { headers });
  }
  updateLeaveRequest(leaveRequestId: number, requestObject: LeaveRequest): Observable<LeaveRequest> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.put<LeaveRequest>(`${this.apiUrl}/api/leaverequest/${leaveRequestId}`, requestObject, { headers });
  }

  deleteLeaveRequest(leaveRequestId: number): Observable<void> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.delete<void>(`${this.apiUrl}/api/leaverequest/${leaveRequestId}`, { headers });
  }
}
