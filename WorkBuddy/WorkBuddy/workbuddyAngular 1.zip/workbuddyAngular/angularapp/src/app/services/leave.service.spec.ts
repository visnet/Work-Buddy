import { TestBed } from '@angular/core/testing';

import { LeaveService } from './leave.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('LeaveService', () => {
  let service: LeaveService;

  beforeEach(() => {
    TestBed.configureTestingModule({  imports: [HttpClientTestingModule],});
    service = TestBed.inject(LeaveService);
  });

  fit('Frontend_should_create_leave_service', () => {
    expect(service).toBeTruthy();
  });
});
