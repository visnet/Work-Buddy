import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { apiUrl } from 'src/apiconfig';
import { WfhRequest } from '../models/wfhRequest.model';

@Injectable({
  providedIn: 'root'
})
export class WfhService {
  public apiUrl = apiUrl; // Update with your API URL

  constructor(private http: HttpClient) { }

  getAllWfhRequests(): Observable<WfhRequest[]> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.get<WfhRequest[]>(`${this.apiUrl}/api/wfhrequest`, { headers });
  }

  getWfhRequestById(wfhRequestId:number): Observable<WfhRequest> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.get<WfhRequest>(`${this.apiUrl}/api/wfhrequest/${wfhRequestId}`, { headers });
  }

  addWfhRequest(requestObject: WfhRequest): Observable<WfhRequest> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.post<WfhRequest>(`${this.apiUrl}/api/wfhrequest`, requestObject, { headers });
  }

  updateWfhRequest(wfhRequestId: number, requestObject: WfhRequest): Observable<WfhRequest> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.put<WfhRequest>(`${this.apiUrl}/api/wfhrequest/${wfhRequestId}`, requestObject, { headers });
  }

  deleteWfhRequest(wfhRequestId: number): Observable<void> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.delete<void>(`${this.apiUrl}/api/wfhrequest/${wfhRequestId}`, { headers });
  }

  getWfhRequestsByUserId(userId: number): Observable<WfhRequest[]> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.get<WfhRequest[]>(`${this.apiUrl}/api/wfhrequest/user/${userId}`, { headers });
  }

}
