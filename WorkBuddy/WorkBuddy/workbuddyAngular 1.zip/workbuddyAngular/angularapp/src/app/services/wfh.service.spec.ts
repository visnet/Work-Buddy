import { TestBed } from '@angular/core/testing';

import { WfhService } from './wfh.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('WfhService', () => {
  let service: WfhService;

  beforeEach(() => {
    TestBed.configureTestingModule({  imports: [HttpClientTestingModule],});
    service = TestBed.inject(WfhService);
  });

  fit('Frontend_should_create_wfh_service', () => {
    expect(service).toBeTruthy();
  });
});
