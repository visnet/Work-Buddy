import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { apiUrl } from 'src/apiconfig';
import { User } from '../models/user.model'; // Assuming you have an Employee model

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  public apiUrl = apiUrl;

  constructor(private http: HttpClient) { }

  getAllEmployees(): Observable<User[]> {
    const headers = new HttpHeaders({
      'Authorization': 'Bearer ' + localStorage.getItem('token')
    });
    return this.http.get<User[]>(`${this.apiUrl}/api/employees`, { headers });
  }
}
