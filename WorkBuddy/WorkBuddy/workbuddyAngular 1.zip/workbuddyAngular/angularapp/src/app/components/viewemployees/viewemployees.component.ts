import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/models/user.model'; // Import the Employee model
import { EmployeeService } from 'src/app/services/employee.service'; // Import the EmployeeService

@Component({
  selector: 'app-viewemployees',
  templateUrl: './viewemployees.component.html',
  styleUrls: ['./viewemployees.component.css']
})
export class ViewemployeesComponent implements OnInit {
  employees: User[] = [];

  constructor(private employeeService: EmployeeService) { }

  ngOnInit(): void {
    this.fetchEmployees();
  }

  fetchEmployees(): void {
    this.employeeService.getAllEmployees().subscribe(
      (employees: User[]) => {
        console.log("employees",employees);
        this.employees = employees;
      },
      (error) => {
        console.error('Error fetching employees:', error);
        // Handle error appropriately
      }
    );
  }
}
