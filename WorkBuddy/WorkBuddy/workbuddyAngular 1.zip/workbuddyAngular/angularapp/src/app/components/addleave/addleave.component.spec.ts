import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddleaveComponent } from './addleave.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('AddleaveComponent', () => {
  let component: AddleaveComponent;
  let fixture: ComponentFixture<AddleaveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, RouterTestingModule, HttpClientTestingModule, FormsModule],
      declarations: [ AddleaveComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddleaveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  fit('Frontend_should_create_addleave_component', () => {
    expect(component).toBeTruthy();
  });


});
