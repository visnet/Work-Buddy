import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MywfhComponent } from './mywfh.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('MywfhComponent', () => {
  let component: MywfhComponent;
  let fixture: ComponentFixture<MywfhComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, RouterTestingModule, HttpClientTestingModule, FormsModule],
      declarations: [ MywfhComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MywfhComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  fit('Frontend_should_create_mywfh_component', () => {
    expect(component).toBeTruthy();
  });

  fit('Frontend_should_contain_wfh_requests_heading_in_the_mywfh_component', () => {
    const componentHTML = fixture.debugElement.nativeElement.outerHTML;
    expect(componentHTML).toContain('WFH Requests');
  });
});
