import { Component, OnInit } from '@angular/core';
import { LeaveService } from 'src/app/services/leave.service'; // Import your Leave service

@Component({
  selector: 'app-viewleave',
  templateUrl: './viewleave.component.html',
  styleUrls: ['./viewleave.component.css']
})
export class ViewleaveComponent implements OnInit {
  leaveRequests: any[] = [];
  filteredRequests: any[] = [];
  searchValue = '';
  statusFilter = '-1';
  showModal = false;
  selectedRequest: any = null;

  constructor(private leaveService: LeaveService) { }

  ngOnInit(): void {
    this.fetchData();
  }

  fetchData(): void {
    this.leaveService.getAllLeaveRequests().subscribe(
      (response) => {
        console.log("response",response);
        this.leaveRequests = response;
        this.filteredRequests = [...this.leaveRequests];
      },
      (error) => {
        console.error('Error fetching leave requests:', error);
        // Handle error appropriately
      }
    );
  }

  handleApprove(request: any): void {
    request.Status = 'Approved';
    this.updateLeaveRequest(request);
  }

  handleReject(request: any): void {
    request.Status = 'Rejected';
    this.updateLeaveRequest(request);
  }

  updateLeaveRequest(request: any): void {
    const requestId = request.LeaveRequestId; // Assuming 'id' is the property that represents the ID of the request

    this.leaveService.updateLeaveRequest(requestId, request).subscribe(
      (response) => {
        console.log('Response:', response);
        this.fetchData();
      },
      (error) => {
        console.error('Error updating leave request:', error);
        // Handle error appropriately
      }
    );
  }

  handleRowExpand(index: number): void {
    const selected = this.filteredRequests[index];
    this.selectedRequest = selected;
    this.showModal = !this.showModal;
  }

  closeRequestDetailsModal(): void {
    this.showModal = false;
  }
}
