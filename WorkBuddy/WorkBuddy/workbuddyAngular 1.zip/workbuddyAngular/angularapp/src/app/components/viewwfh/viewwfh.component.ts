import { Component, OnInit } from '@angular/core';
import { WfhService } from 'src/app/services/wfh.service'; // Import your WFH service

@Component({
  selector: 'app-viewwfh',
  templateUrl: './viewwfh.component.html',
  styleUrls: ['./viewwfh.component.css']
})
export class ViewwfhComponent implements OnInit {
  wfhRequests: any[] = [];
  filteredRequests: any[] = [];
  searchValue = '';
  statusFilter = '-1';
  showModal = false;
  selectedRequest: any = null;

  constructor(private wfhService: WfhService) { }

  ngOnInit(): void {
    this.fetchData();
  }

  fetchData(): void {
    this.wfhService.getAllWfhRequests().subscribe(
      (response) => {
        console.log("response",response);
        this.wfhRequests = response;
        this.filteredRequests = [...this.wfhRequests];
      },
      (error) => {
        console.error('Error fetching WFH requests:', error);
        // Handle error appropriately
      }
    );
  }

  handleApprove(request: any): void {
    request.Status = 'Approved';
    this.updateWfhRequest(request);
  }

  handleReject(request: any): void {
    request.Status = 'Rejected';
    this.updateWfhRequest(request);
  }

  updateWfhRequest(request: any): void {
    const requestId = request.WfhRequestId; // Assuming 'id' is the property that represents the ID of the request

    this.wfhService.updateWfhRequest(requestId,request).subscribe(
      (response) => {
        console.log('Response:', response);
        this.fetchData();
      },
      (error) => {
        console.error('Error updating WFH request:', error);
        // Handle error appropriately
      }
    );
  }

  handleRowExpand(index: number): void {
    const selected = this.filteredRequests[index];
    this.selectedRequest = selected;
    this.showModal = !this.showModal;
  }

  closeRequestDetailsModal(): void {
    this.showModal = false;
  }


}
