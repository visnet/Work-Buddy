import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewwfhComponent } from './viewwfh.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('ViewwfhComponent', () => {
  let component: ViewwfhComponent;
  let fixture: ComponentFixture<ViewwfhComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, RouterTestingModule, HttpClientTestingModule, FormsModule],
      declarations: [ ViewwfhComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewwfhComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  fit('Frontend_should_create_viewwfh_component', () => {
    expect(component).toBeTruthy();
  });

  fit('Frontend_should_contain_wfh_requests_for_approval_heading_in_the_viewwfh_component', () => {
    const componentHTML = fixture.debugElement.nativeElement.outerHTML;
    expect(componentHTML).toContain('WFH Requests for Approval');
  });
});
