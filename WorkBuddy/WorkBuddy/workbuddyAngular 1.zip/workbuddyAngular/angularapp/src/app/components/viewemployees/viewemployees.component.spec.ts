import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewemployeesComponent } from './viewemployees.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('ViewemployeesComponent', () => {
  let component: ViewemployeesComponent;
  let fixture: ComponentFixture<ViewemployeesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, RouterTestingModule, HttpClientTestingModule, FormsModule],
      declarations: [ ViewemployeesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewemployeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  fit('Frontend_should_create_viewemployees_component', () => {
    expect(component).toBeTruthy();
  });

  fit('Frontend_should_contain_view_employees_heading_in_the_viewemployees_component', () => {
    const componentHTML = fixture.debugElement.nativeElement.outerHTML;
    expect(componentHTML).toContain('View Employees');
  });
});
