// mywfh.component.ts
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { WfhService } from 'src/app/services/wfh.service';

@Component({
  selector: 'app-mywfh',
  templateUrl: './mywfh.component.html',
  styleUrls: ['./mywfh.component.css']
})
export class MywfhComponent implements OnInit {

  wfhRequests: any[] = [];
  showDeletePopup = false;
  requestToDelete: number | null = null;
  searchValue = '';
  maxRecords = 1;
  totalPages = 1;
  status: string = '';
  allRequests: any[] = [];

  constructor(private router: Router, private wfhService: WfhService) {}

  ngOnInit(): void {
    this.fetchWfhRequests();
  }

  fetchWfhRequests() {
    const userId = parseInt(localStorage.getItem('userId'));
    if (userId) {
      this.wfhService.getWfhRequestsByUserId(userId).subscribe(
        (data: any) => {
          this.wfhRequests = data;
          this.allRequests = data;
          console.log('WFH requests:', this.wfhRequests);
        },
        (error) => {
          console.error('Error fetching WFH requests:', error);
        }
      );
    }
  }

  handleDeleteClick(requestId: number) {
    this.requestToDelete = requestId;
    this.showDeletePopup = true;
  }

  editRequest(requestId: number) {
    this.router.navigate(['/employee/editwfh', requestId]);
  }

  handleConfirmDelete() {
    if (this.requestToDelete) {
      this.wfhService.deleteWfhRequest(this.requestToDelete).subscribe(
        () => {
          console.log('WFH request deleted successfully');
          this.closeDeletePopup();
          this.fetchWfhRequests();
        },
        (error) => {
          console.error('Error deleting WFH request:', error);
        }
      );
    }
  }

  closeDeletePopup() {
    this.requestToDelete = null;
    this.showDeletePopup = false;
  }


}
