import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyleaveComponent } from './myleave.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('MyleaveComponent', () => {
  let component: MyleaveComponent;
  let fixture: ComponentFixture<MyleaveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, RouterTestingModule, HttpClientTestingModule, FormsModule],
      declarations: [ MyleaveComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MyleaveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  fit('Frontend_should_create_myleave_component', () => {
    expect(component).toBeTruthy();
  });

  fit('Frontend_should_contain_leave_requests_heading_in_the_myleave_component', () => {
    const componentHTML = fixture.debugElement.nativeElement.outerHTML;
    expect(componentHTML).toContain('Leave Requests');
  });
});
