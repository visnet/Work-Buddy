import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LeaveService } from 'src/app/services/leave.service'; // Replace 'leave.service' with your actual service name
import { LeaveRequest } from 'src/app/models/leaveRequest.model'; // Import the LeaveRequest interface

@Component({
  selector: 'app-addleave',
  templateUrl: './addleave.component.html',
  styleUrls: ['./addleave.component.css']
})
export class AddleaveComponent implements OnInit {

  leaveForm: FormGroup;
  successPopup = false;
  errorMessage = "";
  today = new Date().toISOString().split('T')[0];
  maxDate = this.today;
  isEditMode = false;
  leaveRequestId: string;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private leaveService: LeaveService, // Replace 'WfhService' with your actual service name
    private route: ActivatedRoute
  ) {
    this.leaveForm = this.fb.group({
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      reason: ['', Validators.required],
      leaveType: ['', Validators.required] // Add validators for Leave Type
    });
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.leaveRequestId = params.get('id');
      if (this.leaveRequestId) {
        this.isEditMode = true;
        this.loadLeaveRequest();
      }
    });
  }

  loadLeaveRequest(): void {
    this.leaveService.getLeaveRequestById(parseInt(this.leaveRequestId)).subscribe(
      (response: LeaveRequest) => {
        // Adjust dates to local timezone
        const startDate = new Date(response.StartDate);
        const endDate = new Date(response.EndDate);

        // Set form values
        this.leaveForm.setValue({
          startDate: this.adjustToLocalDate(startDate).toISOString().split('T')[0], // Adjust to local date and convert to ISO string
          endDate: this.adjustToLocalDate(endDate).toISOString().split('T')[0],     // Adjust to local date and convert to ISO string
          reason: response.Reason,
          leaveType: response.LeaveType // Set Leave Type value
        });
      },
      (error) => {
        console.error('Error fetching leave request details:', error);
        this.router.navigate(['/error']);
      }
    );
  }

  adjustToLocalDate(date: Date): Date {
    const localDate = new Date(date);
    localDate.setMinutes(localDate.getMinutes() - localDate.getTimezoneOffset());
    return localDate;
  }

  onSubmit(): void {
    if (this.leaveForm.valid) {
      const formData = this.leaveForm.value;

      // Convert start and end dates to local date objects
      const startDate = new Date(formData.startDate);
      const endDate = new Date(formData.endDate);

      const requestObject: LeaveRequest = {
        UserId: Number(localStorage.getItem('userId')),
        StartDate: startDate, // Use Date object
        EndDate: endDate,     // Use Date object
        Reason: formData.reason,
        LeaveType: formData.leaveType, // Use form value for Leave Type
        Status: 'Pending',
        CreatedOn: new Date()
      };

      if (this.isEditMode) {
        this.leaveService.updateLeaveRequest(parseInt(this.leaveRequestId), requestObject).subscribe(
          (response) => {
            console.log('Leave request updated successfully', response);
            this.successPopup = true;
          },
          (error) => {
            console.error('Error updating leave request:', error);
            this.errorMessage = error.error.message;
          }
        );
      } else {
        this.leaveService.addLeaveRequest(requestObject).subscribe(
          (response) => {
            console.log('Leave request added successfully', response);
            this.successPopup = true;
          },
          (error) => {
            console.error('Error submitting leave request:', error);
            this.errorMessage = error.error.message;
          }
        );
      }
    } else {
      this.errorMessage = "All fields are required";
    }
  }
  
  handleSuccessMessage(): void {
    this.successPopup = false;
    this.router.navigate(['/employee/view/leave']); // Navigate to the desired route
  }

}
