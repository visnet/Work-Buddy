import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { WfhService } from 'src/app/services/wfh.service';

@Component({
  selector: 'app-addwfh',
  templateUrl: './addwfh.component.html',
  styleUrls: ['./addwfh.component.css']
})
export class AddwfhComponent implements OnInit {

  wfhForm: FormGroup;
  successPopup = false;
  errorMessage = "";
  today = new Date().toISOString().split('T')[0];
  maxDate = this.today;
  isEditMode = false;
  wfhRequestId: string;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private wfhService: WfhService,
    private route: ActivatedRoute
  ) {
    this.wfhForm = this.fb.group({
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      reason: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.wfhRequestId = params.get('id');
      if (this.wfhRequestId) {
        this.isEditMode = true;
        this.loadWfhRequest();
      }
    });
  }

  loadWfhRequest(): void {
    this.wfhService.getWfhRequestById(parseInt(this.wfhRequestId)).subscribe(
      (response) => {
        // Adjust dates to local timezone
        const startDate = new Date(response.StartDate);
        const endDate = new Date(response.EndDate);
        
        // Set form values
        this.wfhForm.setValue({
          startDate: this.adjustToLocalDate(startDate).toISOString().split('T')[0], // Adjust to local date and convert to ISO string
          endDate: this.adjustToLocalDate(endDate).toISOString().split('T')[0],     // Adjust to local date and convert to ISO string
          reason: response.Reason
        });
      },
      (error) => {
        console.error('Error fetching WFH request details:', error);
        this.router.navigate(['/error']);
      }
    );
  }

  adjustToLocalDate(date: Date): Date {
    const localDate = new Date(date);
    localDate.setMinutes(localDate.getMinutes() - localDate.getTimezoneOffset());
    return localDate;
  }

  onSubmit(): void {
    if (this.wfhForm.valid) {
      const formData = this.wfhForm.value;

      // Convert start and end dates to local date objects
      const startDate = new Date(formData.startDate);
      const endDate = new Date(formData.endDate);

      const requestObject  = {
        UserId: Number(localStorage.getItem('userId')),
        StartDate: startDate, // Use Date object
        EndDate: endDate,     // Use Date object
        Reason: formData.reason,
        Status: 'Pending',
        CreatedOn: new Date()
      };

      if (this.isEditMode) {
        this.wfhService.updateWfhRequest(parseInt(this.wfhRequestId), requestObject).subscribe(
          (response) => {
            console.log('WFH request updated successfully', response);
            this.successPopup = true;
          },
          (error) => {
            console.error('Error updating WFH request:', error);
            this.errorMessage = error.error.message;
          }
        );
      } else {
        this.wfhService.addWfhRequest(requestObject).subscribe(
          (response) => {
            console.log('WFH request added successfully', response);
            this.successPopup = true;
          },
          (error) => {
            console.error('Error submitting WFH request:', error);
            this.errorMessage = error.error.message;
          }
        );
      }
    } else {
      this.errorMessage = "All fields are required";
    }
  }
  
  handleSuccessMessage(): void {
    this.successPopup = false;
    this.router.navigate(['/employee/view/wfh']); // Navigate to the desired route
  }

}
