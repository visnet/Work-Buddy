import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewleaveComponent } from './viewleave.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('ViewleaveComponent', () => {
  let component: ViewleaveComponent;
  let fixture: ComponentFixture<ViewleaveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, RouterTestingModule, HttpClientTestingModule, FormsModule],
      declarations: [ ViewleaveComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewleaveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  fit('Frontend_should_create_viewleave_component', () => {
    expect(component).toBeTruthy();
  });

  fit('Frontend_should_contain_leave_requests_for_approval_heading_in_the_viewleave_component', () => {
    const componentHTML = fixture.debugElement.nativeElement.outerHTML;
    expect(componentHTML).toContain('Leave Requests for Approval');
  });
});
