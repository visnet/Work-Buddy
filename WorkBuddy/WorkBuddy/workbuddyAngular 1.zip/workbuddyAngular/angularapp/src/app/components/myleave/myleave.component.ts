import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LeaveService } from 'src/app/services/leave.service';

@Component({
  selector: 'app-myleave',
  templateUrl: './myleave.component.html',
  styleUrls: ['./myleave.component.css']
})
export class MyleaveComponent implements OnInit {

  leaveRequests: any[] = [];
  showDeletePopup = false;
  requestToDelete: number | null = null;
  searchValue = '';
  maxRecords = 1;
  totalPages = 1;
  status: string = '';
  allRequests: any[] = [];

  constructor(private router: Router, private leaveService: LeaveService) {}

  ngOnInit(): void {
    this.fetchLeaveRequests();
  }

  fetchLeaveRequests() {
    const userId = parseInt(localStorage.getItem('userId'));
    if (userId) {
      this.leaveService.getLeaveRequestsByUserId(userId).subscribe(
        (data: any) => {
          this.leaveRequests = data;
          this.allRequests = data;
          console.log('Leave requests:', this.leaveRequests);
        },
        (error) => {
          console.error('Error fetching leave requests:', error);
        }
      );
    }
  }

  handleDeleteClick(requestId: number) {
    this.requestToDelete = requestId;
    this.showDeletePopup = true;
  }

  editRequest(requestId: number) {
    this.router.navigate(['/employee/editleave', requestId]);
  }

  handleConfirmDelete() {
    if (this.requestToDelete) {
      this.leaveService.deleteLeaveRequest(this.requestToDelete).subscribe(
        () => {
          console.log('Leave request deleted successfully');
          this.closeDeletePopup();
          this.fetchLeaveRequests();
        },
        (error) => {
          console.error('Error deleting leave request:', error);
        }
      );
    }
  }

  closeDeletePopup() {
    this.requestToDelete = null;
    this.showDeletePopup = false;
  }
}
