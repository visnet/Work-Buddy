import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddwfhComponent } from './addwfh.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('AddwfhComponent', () => {
  let component: AddwfhComponent;
  let fixture: ComponentFixture<AddwfhComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, RouterTestingModule, HttpClientTestingModule, FormsModule],
      declarations: [ AddwfhComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddwfhComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  fit('Frontend_should_create_addwfh_component', () => {
    expect(component).toBeTruthy();
  });

});
