export class LeaveRequest {
    LeaveRequestId?: number;
    UserId: number;
    StartDate: Date;
    EndDate: Date;
    Reason: string;
    LeaveType: string;
    Status: string;
    CreatedOn: Date;
  }
  