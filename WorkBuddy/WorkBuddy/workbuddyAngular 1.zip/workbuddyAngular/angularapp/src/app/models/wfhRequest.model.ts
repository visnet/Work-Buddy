export class WfhRequest {
    WfhRequestId?: number;
    UserId: number;
    StartDate: Date;
    EndDate: Date;
    Reason: string;
    Status: string;
    CreatedOn: Date;
  }
  