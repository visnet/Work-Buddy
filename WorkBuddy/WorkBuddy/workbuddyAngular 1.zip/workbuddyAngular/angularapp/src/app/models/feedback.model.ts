export class Feedback {
  FeedbackId?: number;
  UserId: number;
  FeedbackText: string;
  Date: Date;
}
